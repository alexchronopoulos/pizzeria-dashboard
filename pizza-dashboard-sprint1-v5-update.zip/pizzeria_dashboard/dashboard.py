from __future__ import annotations

from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from flask import Blueprint, current_app, redirect, render_template, request, url_for

from .sample_data import build_sample_service
from .service_state import (
    build_inventory_summary,
    load_state,
    save_state,
    state_from_form,
)

blueprint = Blueprint("dashboard", __name__)


def _now() -> datetime:
    timezone = ZoneInfo(current_app.config["SERVICE_TIMEZONE"])
    return datetime.now(timezone)


def _state_path() -> Path:
    return Path(current_app.config["SERVICE_STATE_PATH"])


@blueprint.get("/")
def index() -> str:
    service = build_sample_service()
    inventory = build_inventory_summary(service, load_state(_state_path()))
    return render_template(
        "dashboard.html",
        service=service,
        inventory=inventory,
        last_synced=_now(),
    )


@blueprint.post("/inventory")
def update_inventory():
    save_state(_state_path(), state_from_form(request.form))
    return redirect(url_for("dashboard.index"), code=303)


@blueprint.post("/sync")
def sync():
    """Refresh the board. Square polling will replace this placeholder later."""
    return redirect(url_for("dashboard.index"), code=303)


@blueprint.get("/healthz")
def healthz() -> tuple[dict[str, str], int]:
    return {"status": "ok"}, 200
