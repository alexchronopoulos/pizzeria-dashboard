from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .sample_data import SALAD_TYPES, ServiceBoard


DEFAULT_DOUGH_BALLS = 24
DEFAULT_SALAD_PREPARED = {
    "Cucumber Salad": 8,
    "Kale Caesar Salad": 8,
}


@dataclass(frozen=True, slots=True)
class ServiceState:
    dough_balls_prepared: int
    salad_prepared: dict[str, int]


@dataclass(frozen=True, slots=True)
class SaladStock:
    name: str
    field_name: str
    prepared: int
    ordered: int
    remaining: int


@dataclass(frozen=True, slots=True)
class InventorySummary:
    dough_prepared: int
    dough_ordered: int
    dough_remaining: int
    salads: tuple[SaladStock, ...]


def salad_field_name(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return f"salad_{slug}"


def _nonnegative_int(value: object, fallback: int = 0) -> int:
    try:
        return max(int(value), 0)
    except (TypeError, ValueError):
        return fallback


def default_state() -> ServiceState:
    return ServiceState(
        dough_balls_prepared=DEFAULT_DOUGH_BALLS,
        salad_prepared=dict(DEFAULT_SALAD_PREPARED),
    )


def load_state(path: Path) -> ServiceState:
    defaults = default_state()
    if not path.exists():
        return defaults

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return defaults

    raw_salads = raw.get("salad_prepared", {})
    salads = {
        name: _nonnegative_int(raw_salads.get(name), defaults.salad_prepared.get(name, 0))
        for name in SALAD_TYPES
    }
    return ServiceState(
        dough_balls_prepared=_nonnegative_int(
            raw.get("dough_balls_prepared"), defaults.dough_balls_prepared
        ),
        salad_prepared=salads,
    )


def save_state(path: Path, state: ServiceState) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(f"{path.suffix}.tmp")
    payload = {
        "dough_balls_prepared": state.dough_balls_prepared,
        "salad_prepared": state.salad_prepared,
    }
    temporary_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    temporary_path.replace(path)


def state_from_form(form: Mapping[str, str]) -> ServiceState:
    defaults = default_state()
    return ServiceState(
        dough_balls_prepared=_nonnegative_int(
            form.get("dough_balls_prepared"), defaults.dough_balls_prepared
        ),
        salad_prepared={
            name: _nonnegative_int(
                form.get(salad_field_name(name)), defaults.salad_prepared.get(name, 0)
            )
            for name in SALAD_TYPES
        },
    )


def build_inventory_summary(
    service: ServiceBoard,
    state: ServiceState,
) -> InventorySummary:
    salad_counts = service.salad_counts
    salads = tuple(
        SaladStock(
            name=name,
            field_name=salad_field_name(name),
            prepared=state.salad_prepared.get(name, 0),
            ordered=salad_counts.get(name, 0),
            remaining=state.salad_prepared.get(name, 0) - salad_counts.get(name, 0),
        )
        for name in SALAD_TYPES
    )
    return InventorySummary(
        dough_prepared=state.dough_balls_prepared,
        dough_ordered=service.total_pizzas,
        dough_remaining=state.dough_balls_prepared - service.total_pizzas,
        salads=salads,
    )
