from pizzeria_dashboard import create_app
from pizzeria_dashboard.sample_data import build_sample_service


def test_dashboard_renders_multiple_orders_and_pizza_totals() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert response.status_code == 200
    assert b"Pizzeria Mari" in response.data
    assert b"Production board" in response.data
    assert b"Tomato Pie" in response.data
    assert b"3 pizzas" in response.data
    assert b"3 orders" not in response.data
    assert response.data.count(b'class="order-row') >= 3


def test_release_candidates_consider_total_slot_capacity() -> None:
    service = build_sample_service()
    candidates = {
        order.order_id
        for window in service.windows
        for order in window.orders
        if service.is_release_candidate(order, window)
    }

    assert candidates == {"PM-1047", "PM-1053"}
    assert service.release_candidates == 2


def test_release_candidate_tags_render_only_for_eligible_orders() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert response.data.count(b"Release candidate") == 3  # Summary label + two tags.
    assert b"Lee C." in response.data  # One pie, but in a full three-pizza slot.


def test_modifiers_render_with_their_pizza_items() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert b"Plain Pie" in response.data
    assert b"Pepperoni" in response.data
    assert b"White Pie" in response.data
    assert b"Pickled chiles" in response.data
    assert b"Basil" in response.data
    assert b'aria-label="Modifiers for White Pie"' in response.data


def test_salad_orders_are_highlighted() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert b"Salad \xc3\x971" in response.data
    assert b"Salad \xc3\x972" in response.data
    assert b"order-row--salad" in response.data


def test_drinks_are_hidden_from_production_view() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert b"Mexican Coke" not in response.data
    assert b"Sparkling Water" not in response.data
    assert b"Jamie Q." not in response.data


def test_sample_service_groups_two_or_three_orders_per_window() -> None:
    service = build_sample_service()

    assert any(window.order_count == 3 for window in service.windows)
    assert any(window.order_count == 2 for window in service.windows)
    assert all(window.order_count in {2, 3} for window in service.windows)


def test_sync_redirects_to_dashboard() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.post("/sync")

    assert response.status_code == 303
    assert response.headers["Location"].endswith("/")


def test_health_endpoint() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/healthz")

    assert response.status_code == 200
    assert response.get_json() == {"status": "ok"}
