from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time
from typing import Iterable


@dataclass(frozen=True, slots=True)
class Item:
    name: str
    quantity: int
    category: str
    modifiers: tuple[str, ...] = ()

    @property
    def pizza_units(self) -> int:
        return self.quantity if self.category == "pizza" else 0


@dataclass(frozen=True, slots=True)
class Order:
    order_id: str
    customer_name: str
    pickup_at: datetime
    items: tuple[Item, ...]
    released: bool = False

    @property
    def production_items(self) -> tuple[Item, ...]:
        """Items the kitchen dashboard should display.

        Drinks remain in the source order data, but they are intentionally hidden
        from this production-focused view.
        """
        return tuple(item for item in self.items if item.category != "drink")

    @property
    def pizza_units(self) -> int:
        return sum(item.pizza_units for item in self.items)

    @property
    def salad_count(self) -> int:
        return sum(item.quantity for item in self.items if item.category == "salad")

    @property
    def has_salad(self) -> bool:
        return self.salad_count > 0

    @property
    def is_single_pie_unreleased(self) -> bool:
        return self.pizza_units == 1 and not self.released


@dataclass(frozen=True, slots=True)
class PickupWindow:
    pickup_at: datetime
    orders: tuple[Order, ...]

    @property
    def pizza_units(self) -> int:
        return sum(order.pizza_units for order in self.orders)

    @property
    def order_count(self) -> int:
        return len(self.orders)


@dataclass(frozen=True, slots=True)
class ServiceBoard:
    service_date: date
    windows: tuple[PickupWindow, ...]
    pizza_capacity_per_window: int

    @property
    def total_orders(self) -> int:
        return sum(window.order_count for window in self.windows)

    @property
    def total_pizzas(self) -> int:
        return sum(window.pizza_units for window in self.windows)

    @property
    def total_salads(self) -> int:
        return sum(order.salad_count for window in self.windows for order in window.orders)

    def is_release_candidate(self, order: Order, window: PickupWindow) -> bool:
        """Return whether a one-pie order can safely release Square capacity.

        A one-pie order is only highlighted when the entire 15-minute slot is
        still below configured pizza capacity. Released orders are never shown as
        candidates.
        """
        return (
            order.is_single_pie_unreleased
            and window.pizza_units < self.pizza_capacity_per_window
        )

    @property
    def release_candidates(self) -> int:
        return sum(
            1
            for window in self.windows
            for order in window.orders
            if self.is_release_candidate(order, window)
        )


def _service_datetime(hour: int, minute: int) -> datetime:
    # Keep fake data deterministic and easy to recognize in screenshots/tests.
    return datetime.combine(date(2026, 7, 31), time(hour, minute))


def _group_orders(orders: Iterable[Order]) -> tuple[PickupWindow, ...]:
    grouped: dict[datetime, list[Order]] = defaultdict(list)
    for order in orders:
        # Drink-only orders do not create kitchen work and are omitted from the board.
        if not order.production_items:
            continue
        grouped[order.pickup_at].append(order)

    return tuple(
        PickupWindow(pickup_at=pickup_at, orders=tuple(grouped[pickup_at]))
        for pickup_at in sorted(grouped)
    )


def build_sample_service() -> ServiceBoard:
    """Return realistic sample data with two or three orders in each window."""
    orders = (
        Order(
            order_id="PM-1042",
            customer_name="Alex R.",
            pickup_at=_service_datetime(16, 0),
            items=(
                Item("Tomato Pie", 1, "pizza"),
                Item("Mexican Coke", 2, "drink"),
            ),
        ),
        Order(
            order_id="PM-1043",
            customer_name="Robin S.",
            pickup_at=_service_datetime(16, 0),
            items=(Item("Plain Pie", 1, "pizza", modifiers=("Pepperoni",)),),
        ),
        Order(
            order_id="PM-1044",
            customer_name="Priya N.",
            pickup_at=_service_datetime(16, 0),
            items=(Item("Weekly Special", 1, "pizza"),),
        ),
        Order(
            order_id="PM-1045",
            customer_name="Maya T.",
            pickup_at=_service_datetime(16, 15),
            items=(
                Item("Plain Pie", 1, "pizza"),
                Item(
                    "White Pie",
                    1,
                    "pizza",
                    modifiers=("Pickled chiles", "Basil"),
                ),
                Item("Little Gem Salad", 1, "salad"),
            ),
        ),
        Order(
            order_id="PM-1046",
            customer_name="Lee C.",
            pickup_at=_service_datetime(16, 15),
            items=(
                Item("Tomato Pie", 1, "pizza"),
                Item("Sparkling Water", 1, "drink"),
            ),
        ),
        Order(
            order_id="PM-1047",
            customer_name="Jordan K.",
            pickup_at=_service_datetime(16, 30),
            items=(Item("Weekly Special", 1, "pizza"),),
        ),
        Order(
            order_id="PM-1048",
            customer_name="Morgan F.",
            pickup_at=_service_datetime(16, 30),
            items=(Item("White Pie", 1, "pizza", modifiers=("Basil",)),),
            released=True,
        ),
        Order(
            order_id="PM-1049",
            customer_name="Jules P.",
            pickup_at=_service_datetime(16, 30),
            items=(Item("Little Gem Salad", 1, "salad"),),
        ),
        Order(
            order_id="PM-1050",
            customer_name="Sam D.",
            pickup_at=_service_datetime(16, 45),
            items=(Item("Plain Pie", 2, "pizza"),),
        ),
        Order(
            order_id="PM-1051",
            customer_name="Casey W.",
            pickup_at=_service_datetime(16, 45),
            items=(Item("Weekly Special", 1, "pizza"),),
        ),
        Order(
            order_id="PM-1052",
            customer_name="Chris M.",
            pickup_at=_service_datetime(17, 0),
            items=(
                Item("White Pie", 1, "pizza"),
                Item("Little Gem Salad", 2, "salad"),
            ),
            released=True,
        ),
        Order(
            order_id="PM-1053",
            customer_name="Dana A.",
            pickup_at=_service_datetime(17, 0),
            items=(Item("Tomato Pie", 1, "pizza"),),
        ),
        Order(
            order_id="PM-1054",
            customer_name="Taylor B.",
            pickup_at=_service_datetime(17, 15),
            items=(
                Item("Tomato Pie", 1, "pizza"),
                Item("Weekly Special", 1, "pizza"),
            ),
        ),
        Order(
            order_id="PM-1055",
            customer_name="Avery L.",
            pickup_at=_service_datetime(17, 15),
            items=(Item("Plain Pie", 1, "pizza"),),
        ),
        # This order proves that drink-only orders stay out of the production board.
        Order(
            order_id="PM-1056",
            customer_name="Jamie Q.",
            pickup_at=_service_datetime(17, 15),
            items=(Item("Mexican Coke", 2, "drink"),),
        ),
    )

    return ServiceBoard(
        service_date=orders[0].pickup_at.date(),
        windows=_group_orders(orders),
        pizza_capacity_per_window=3,
    )
