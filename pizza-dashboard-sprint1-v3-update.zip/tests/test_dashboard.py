from pizzeria_dashboard import create_app
from pizzeria_dashboard.sample_data import build_sample_service


def test_dashboard_renders_multiple_orders_per_window() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert response.status_code == 200
    assert b"Pizzeria Mari" in response.data
    assert b"Production board" in response.data
    assert b"Tomato Pie" in response.data
    assert b"Release candidate" in response.data
    assert b"3 orders" in response.data
    assert response.data.count(b'class="order-row"') >= 3


def test_drinks_are_hidden_from_production_view() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/")

    assert b"Mexican Coke" not in response.data
    assert b"Sparkling Water" not in response.data
    assert b"Jamie Q." not in response.data


def test_sample_service_groups_two_or_three_orders_per_window() -> None:
    service = build_sample_service()

    assert any(window.order_count == 3 for window in service.windows)
    assert any(window.order_count == 2 for window in service.windows)
    assert all(window.order_count in {2, 3} for window in service.windows)


def test_sync_redirects_to_dashboard() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.post("/sync")

    assert response.status_code == 303
    assert response.headers["Location"].endswith("/")


def test_health_endpoint() -> None:
    app = create_app({"TESTING": True})
    client = app.test_client()

    response = client.get("/healthz")

    assert response.status_code == 200
    assert response.get_json() == {"status": "ok"}
